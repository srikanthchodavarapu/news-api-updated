import React, { Component } from 'react';
// import './App.css';

import SourcesContainer from './containers/sources/SourcesContainer';
import ArticlesContainer from './containers/articles/articleContainer';
import MainNavigation from './components/header/MainNavigation';
class App extends Component {
  render() {
    return (
      <div className="App">      
       <div className="nav">           
            <MainNavigation />
        </div>
        <div className='sources'>
            <SourcesContainer />
        </div>

       <div className='articles'>
            <ArticlesContainer />
        </div>
      </div>
    );  
  }
}

export default App;
