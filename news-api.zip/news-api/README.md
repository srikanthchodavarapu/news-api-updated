# react-news-app

A ReactJS + redux front-end that consumes the articles from 'newsApi.org' API for news articles and their sources, and displays them in UI

1. **One command to get setup** - Type `npm install` to download all required modules.
2. **One command to get started** - Type `npm start` to start development in your default browser.
3. **No more JavaScript fatigue** - I used the most popular and powerful libraries for working with React.
4. **For production build** - Type `npm run build` to do all this:
5. **For Test Scripts** - Type `npm test` to do all this

# Note
Check API Key in apiConfig.js file

# export const _api_key = 'bb4f4f83d5b2448082c068ca767d87b6';

